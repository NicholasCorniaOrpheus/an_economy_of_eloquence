<h1 align="center"> TᴛғDɪᴄᴇ </h1>

<p align=center>A tiny package for displaying TRPG dice.</p>

## Usage

![Usage](https://user-images.githubusercontent.com/76601050/143728601-4fdd547e-262f-47ec-9723-76bbebe7d40e.png)

## Note

This package is build on [dicefont](https://github.com/fponticelli/dicefont) and [Fate Core Glyphs](http://www.faterpg.com/wp-content/uploads/2013/06/Fate-Core-Font.ttf_.zip). Make sure you have them installed.

## Todo

- [ ] Refine tests
- [ ] Write document with docstrip

## Known Issue

- `\D[X]` and `\D*[X]` won't display in math mode. Please wrap them in `\text{}`.

## License

The source code is distributed under LaTeX Project Public License v1.3c.
